"""
`sam traces` command
"""

# Expose the cli object here
from samcli.commands.traces.command import cli
